import * as React from 'react'

export interface AppProps {
    name: string
    location: string
    age: number
}

class App extends React.Component<AppProps, {}> {

    constructor(props: AppProps) {
        super(props)
    }
    render() {
        return(<div className='appContainerClass' id='appContainerClass'>
            <h1>The name is: {this.props.name}</h1>
            <h1>The stay in: {this.props.location}</h1>
            <h1>My Age is: {this.props.name}</h1>
        </div>)
    }
}

export default App