import * as React from 'react'
import { Table } from 'react-bootstrap'
import { hot } from 'react-hot-loader'
const classes = require('./App.css')
import axios from 'axios'
import * as _ from 'lodash'


export interface AppProps {
  name: string
  location: string
  age: number
}

class App extends React.Component<AppProps, {}> {

  constructor(props: AppProps) {
    super(props)
  }

  componentWillMount() {
    let _response: any
    axios.get('http://ergast.com/api/f1/2004/1/results.json').then((response) => {
      _response = response
      /*
      _.isArray(response.data) && response.data.length > 0 &&
      response.data.map((item: any, index: number) => {
        return _.omit(item, 'profile_image')
      })
      */

      console.log(_response)
    })
  }

  render() {
    return (<div className='appContainerClass' id='appContainerClass'>
      <h1>The name is: {this.props.name}</h1>
      <h1>The stay in: {this.props.location}</h1>
      <h1>My Age is: {this.props.name}</h1>
      <Table striped bordered hover variant="dark">
        <thead>
          <tr>
            <th>#</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Username</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>Mark</td>
            <td>Otto</td>
            <td>@mdo</td>
          </tr>
          <tr>
            <td>2</td>
            <td>Jacob</td>
            <td>Thornton</td>
            <td>@fat</td>
          </tr>
          <tr>
            <td>3</td>
            <td>Larry the Bird</td>
            <td>@twitter</td>
          </tr>
        </tbody>
      </Table>
    </div>)
  }
}

export default hot(module)(App)