import * as React from 'react'
import { expect } from 'chai'
require('should')
import { shallow, ShallowWrapper } from 'enzyme'

import App, {AppProps} from '../src/App'

describe('Setting Up Tests', () => {

    let _props: AppProps

    before(() => {
        _props = {
            name: 'James Bond',
            location: 'Great Britain',
            age: 30
        }
    })

    it('should have a parent component', () => {
        let _wrapper = shallow(<App {..._props} />)
        let _appContainerClass= _wrapper.find({id: 'appContainerClass'})
        _appContainerClass.length.should.equal(1, '_appContainerClass')
        let _h1 = _appContainerClass.find('h1')
        _h1.length.should.equal(3, 'h1length')
    })

})
