declare var require: NodeRequire;

import * as enzyme from 'enzyme'
import * as Adapter from 'enzyme-adapter-react-16'

const testsContext = require.context(".", true, /\.spec.ts[x]?$/);
testsContext.keys().forEach(testsContext);

// add all ts files to include non referenced files in report
const srcContext = require.context("../src", true, /\.ts[x]?$/);
srcContext.keys().forEach(srcContext);

enzyme.configure({adapter: new Adapter()})
