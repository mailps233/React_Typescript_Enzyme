import { JSDOM } from 'jsdom'
import * as enzyme from 'enzyme'
import * as Adapter from 'enzyme-adapter-react-16'

interface Global extends NodeJS.Global {
    window: Window,
    document: Document,
    navigator: {
        userAgent: string
    }
}

const globalNode: Global = {
    window: window,
    document: window.document,
    navigator: {
        userAgent: 'node.js',
    },
    ...global
}

if(!globalNode.window && !globalNode.document) {
    const { window } = new JSDOM('<!doctype html><html><body></body></html>', {
        beforeParse(win) {
          win.scrollTo = () => {}
        },
        pretendToBeVisual: false,
        userAgent: 'mocha',
      })
      globalNode.window = window
      globalNode.document = window.document
      globalNode.navigator = window.navigator
}
enzyme.configure({adapter: new Adapter()})


