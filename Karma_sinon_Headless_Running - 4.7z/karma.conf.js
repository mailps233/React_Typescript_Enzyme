let webpackConfig = require('./webpack.config')
const path = require('path')
let _ = require('lodash')

webpackConfig = _.omit(webpackConfig, 'entry')
    // ChromeHeadlessNoSandbox 

module.exports = (config) => {
    config.set({
        // browsers: ["PhantomJS"],
        browsers: ['ChromeHeadless'],
        frameworks: ["mocha", "chai", "sinon-chai", "phantomjs-shim", "es6-shim"],
        // reporters: ["mocha", "spec", "coverage", 'coverage-istanbul'],
        reporters: ["mocha", "coverage", 'coverage-istanbul'],
        files: [
            "test/index.ts"
        ],
        preprocessors: {
            "test/index.ts": ["webpack"],
        },
        mime: {
            "text/x-typescript": ["ts", "tsx"],
        },
        webpack: webpackConfig,
        webpackMiddleware: {
            noInfo: true
        },
        webpackServer: {
            noInfo: true
        },
        colors: true,
        coverageIstanbulReporter: {
            reports: ['html', 'text-summary', 'lcovonly'],
            dir: path.join(__dirname, 'coverage'),
            fixWebpackSourcePaths: true,
            'report-config': {
                html: { outdir: 'html' }
            }
        }
    })
}