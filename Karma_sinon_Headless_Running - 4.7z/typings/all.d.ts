interface NodeRequire {
    ensure: (paths: string[], callback: Function, name?: string) => void;
    context(directory: string, useSubDirectories?: boolean, regExp?: RegExp): any;
}

interface Window {
    appConfig: any;
}

declare module "react-tap-event-plugin" {
    var dummy: any;
    export default dummy;
}

// declare interface ObjectConstructor {
//     assign(obj: any, obj2: any): any;
// }

declare var expect: Chai.ExpectStatic;