import * as React from 'react'
import { Table, Button } from 'react-bootstrap'
import { hot } from 'react-hot-loader'
const classes = require('./App.css')
import axios from 'axios'
import * as _ from 'lodash'


export interface AppProps {
  name: string
  location: string
  age: number
}

export interface AppState {
  employeeRecords: Array<any>
}

class App extends React.Component<AppProps, AppState> {

  constructor(props: AppProps) {
    super(props)
    this.state = {
      employeeRecords: []
    }
  }

  componentWillMount() {
    let _response: any
    axios.get('http://dummy.restapiexample.com/api/v1/employees').then((response) => {
      _response = _.isArray(response.data) && response.data.length > 0 &&
        response.data.map((item: any, index: number) => {
          return _.omit(item, 'profile_image')
        })
      if (_response && _response.length > 0)
        this.setState({ employeeRecords: _response.slice(0, 20) })
    })
  }

  getTableRecords = (records: Array<any>) => {
    let _tabRecords = []

    _tabRecords = records && records.length > 0 && _.map(records, item => {
      return (
        <tr>
          <td>{item.id}</td>
          <td>{item.employee_name}</td>
          <td>{item.employee_salary}</td>
          <td>{item.employee_age}</td>
        </tr>
      )
    })
    return _tabRecords || []
  }

  render() {

    let _tableRecords = this.getTableRecords(this.state.employeeRecords)

    return (<div className='appContainerClass' id='appContainerClass'>
      <div className='headerElements'>
        <h1>The name is: {this.props.name}</h1>
        <h1>The stay in: {this.props.location}</h1>
        <h1>My Age is: {this.props.name}</h1>
        <Button className='buttonClass' variant='primary'>Hello World Danger</Button>
      </div>
      <Table striped bordered hover variant="dark">
        <thead>
          <tr>
            <th>Employee ID</th>
            <th>Employee Name</th>
            <th>Salary</th>
            <th>Age</th>
          </tr>
        </thead>
        <tbody>
          {_tableRecords}
        </tbody>
      </Table>
    </div>)
  }
}

export default hot(module)(App)